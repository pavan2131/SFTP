# import libraries

from tensorflow.keras.layers import Input, Conv1D, MaxPool1D, Bidirectional, LSTM, Dense, Dropout, Flatten
from tensorflow.keras import Sequential
import tensorflow as tf
import os
from sklearn.metrics import explained_variance_score
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import warnings

from datetime import datetime

warnings.filterwarnings("ignore")

pd.set_option("display.max_columns", None)

for dirname, _, filenames in os.walk("input"):
    for filename in filenames:
        print(os.path.join(dirname, filename))


# data loading


def predict_audusd():
    print("----------------------------------------------------------------------------------")
    present_time = datetime.now()
    print("Data Loading Present time:", present_time)
    print("----------------------------------------------------------------------------------")

    df = pd.read_csv("input/AUDUSD=X.csv")

    # df.shape

    # df.head()

    # data preprocessing

    # Printing minimum ans maximum values of each feature

    print("----------------------------------------------------------------------------------")
    present_time = datetime.now()
    print("Data Preprocessing Present time:", present_time)
    print("----------------------------------------------------------------------------------")

    for feature in df.columns:
        minimum_value = df[feature].min()
        maximum_value = df[feature].max()
        print(
            f"Feature Name: {feature:<10} | Minimum value: {minimum_value:<10} | Maximum value: {maximum_value:<10}", "\n")
        print("-"*100)

    df = df.drop(labels='Volume', axis=1)

    # df.head()

    df.isnull().sum()

    df = df.dropna()
    df.isnull().sum()

    # df.info()

    df['Date'] = pd.to_datetime(df['Date'].values)

    # df.head()

    # df.info()

    df['Year'] = df['Date'].dt.year

    # df.head()

    # bar chart

    print("----------------------------------------------------------------------------------")
    present_time = datetime.now()
    print("Bar Chart Present time:", present_time)
    print("----------------------------------------------------------------------------------")

    with plt.style.context(style="fivethirtyeight"):
        plt.figure(figsize=(18, 8))
        ax = sns.countplot(x='Year', data=df, palette="dark")
        plt.title(label="yearwise records size")
        plt.ylim(0, 300)
        for p in ax.patches:
            ax.annotate((p.get_height()), (p.get_x()+0.20, p.get_height()+5))
        # plt.show()
        plt.savefig("static/output/audusd_bar_chart.png")

    # line plots

    print("----------------------------------------------------------------------------------")
    present_time = datetime.now()
    print("Line Plot Present time:", present_time)
    print("----------------------------------------------------------------------------------")

    with plt.style.context(style="fivethirtyeight"):
        fig, axes = plt.subplots(nrows=2, ncols=2, figsize=(20, 10))
        plt.rcParams['font.size'] = 10
        axes = axes.flatten()
        for i, ax in enumerate(axes):
            cols = df.columns[1:5]
            sns.lineplot(data=df, x='Date', y=cols[i], ax=ax)
            ax.set_title(f"Date vs {cols[i]}")
        plt.tight_layout()
        # plt.show()
        plt.savefig("static/output/audusd_line_plots.png")

    # df.head()

    df = df.set_index(keys="Date")
    # df.head()

    df['Year'].unique()

    # df.tail()

    df_train = df.loc[df['Year'] != 2023]
    df_train = df_train[df_train.columns[:-2]]
    df_train.shape

    # df_train.head()

    df_test = df.loc[df['Year'] == 2023]
    df_test = df_test[df_test.columns[:-2]]
    df_test.shape

    # df_test.head()

    X_train = df_train[df_train.columns[:-1]]
    # X_train.head()

    y_train = df_train[df_train.columns[-1:]]
    # y_train.head()

    X_test = df_test[df_test.columns[:-1]]
    # X_test.head()

    y_test = df_test[df_test.columns[-1:]]
    # y_test.head()

    print(f"Shape of X_train: {X_train.shape}")
    print(f"Shape of y_train: {y_train.shape}")

    print(f"Shape of X_test: {X_test.shape}")
    print(f"Shape of y_test: {y_test.shape}")

    X_train = np.array(X_train.values)
    X_test = np.array(X_test.values)
    X_train = np.reshape(X_train, (X_train.shape[0], X_train.shape[1], 1))
    X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1], 1))

    print(f"Shape of X_train: {X_train.shape}")
    print(f"Shape of y_train: {y_train.shape}")

    print(f"Shape of X_test: {X_test.shape}")
    print(f"Shape of y_test: {y_test.shape}")

    print("----------------------------------------------------------------------------------")
    present_time = datetime.now()
    print("Algorithm Present time:", present_time)
    print("----------------------------------------------------------------------------------")

    model = Sequential()
    model.add(Input(shape=(X_train.shape[1], X_train.shape[2])))
    model.add(Conv1D(filters=32, kernel_size=3,
              activation='relu', padding='same'))
    model.add(Conv1D(filters=64, kernel_size=3,
              activation='relu', padding='same'))
    model.add(Bidirectional(LSTM(units=50, return_sequences=True)))
    model.add(Bidirectional(LSTM(units=50, return_sequences=True)))
    model.add(Flatten())
    model.add(Dropout(0.5))
    model.add(Dense(300, activation='relu'))
    model.add(Dense(1))
    model.compile(optimizer='sgd', loss=tf.keras.losses.MeanSquaredError())

    model.summary()

    print("----------------------------------------------------------------------------------")
    present_time = datetime.now()
    print("Model Training Present time:", present_time)
    print("----------------------------------------------------------------------------------")

    history = model.fit(x=X_train, y=y_train.values.ravel(
    ), batch_size=32, epochs=150, validation_data=(X_test, y_test.values.ravel()))

    print("----------------------------------------------------------------------------------")
    present_time = datetime.now()
    print("Model Prediction Present time:", present_time)
    print("----------------------------------------------------------------------------------")

    model_pred = model.predict(X_test, batch_size=16, verbose=1).ravel()
    # print(model_pred)

    # result analysis

    print("----------------------------------------------------------------------------------")
    present_time = datetime.now()
    print("Result Analysis Present time:", present_time)
    print("----------------------------------------------------------------------------------")

    Result = pd.DataFrame()
    Result['True Price'] = y_test.values.ravel()
    Result['Model Prediction'] = model_pred

    # Result.head(10)

    with plt.style.context(style="fivethirtyeight"):
        plt.figure(figsize=(18, 8))
        plt.plot(Result['True Price'].values,
                 label='True Closing Price',
                 marker='o',
                 linestyle='dashed',
                 color='green',
                 linewidth=2,
                 markersize=6)
        plt.plot(Result['Model Prediction'].values,
                 label='Predicted Closing Price',
                 color='black',
                 marker='o',
                 linestyle='dashed',
                 linewidth=2,
                 markersize=6)
        plt.title(
            label='True Closing Price VS Predicted Closing Price', fontsize=30)
        plt.xlabel(xlabel='Number of samples', fontsize=15)
        plt.ylabel(ylabel='Price', fontsize=15)
        plt.legend()
        # plt.show()
        plt.savefig("static/output/audusd_result.png")

    y_true = Result['True Price'].values
    y_pred = Result['Model Prediction'].values

    '''it calculates how far off, on average, the predicted values are from the actual values. '''
    mse = mean_squared_error(y_true, y_pred)
    '''RMSE is derived from MSE by taking the square root. It gives us a measure of the average distance between the predicted values and the actual values. '''
    # mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(y_true, y_pred)
    mae = round(mae, 3)
    r2_score_ = r2_score(y_true, y_pred)
    '''The Explained Variance Score provides an estimate of how well the model captures the variability in the actual values.'''
    evs_score = explained_variance_score(y_true, y_pred)

    print(f"Mean squared error: {mse:.4f}")
    print(f"Root mean squared error: {rmse:.4f}")
    print(f"Mean absolute error: {mae:.4f}")
    print(f"R2 score: {r2_score_:.4f}")
    print(f"Variance score: {evs_score:.4f}")

    # model saving

    print("----------------------------------------------------------------------------------")
    present_time = datetime.now()
    print("Model Saving Present time:", present_time)
    print("----------------------------------------------------------------------------------")

    model.save("models/AUDUSD_model.h5")

    return mse, rmse, mae, r2_score_, evs_score
