a = '10.5454545445'

aa = round(a, 3)

print(aa)